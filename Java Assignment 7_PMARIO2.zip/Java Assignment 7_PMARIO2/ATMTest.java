package com.ford.trainings;

import static org.junit.Assert.*;

import org.junit.Test;

public class ATMTest {
@Test
public void testATM() throws Exception {
	
	ATMManagement atmobj = new ATMManagement();
	atmobj.readFile();
	atmobj.getBalanceEnquiry(1234567);
}
}
