package com.ford.trainings;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;


public class ATMManagement extends AutomatedTellerMachine
{
	public ATMManagement() {
		super();
	}

	public ATMManagement(int accountNumber, String name, String bankname, int balance) {
		super(accountNumber, name, bankname, balance);
	}

	
	ArrayList<AutomatedTellerMachine> atmlist = new ArrayList<AutomatedTellerMachine>();
	private static final String SPACE_DELIMITER=" ";
	
	public void readFile() throws IOException {

		BufferedReader br= null;
		try {
			br= new BufferedReader(new FileReader("C:\\Users\\pmario2\\Desktop\\ATM.txt"));
			String line;
			
			while((line=br.readLine())!=null)
			{
				//System.out.println(line);
				
				String[] atmDetails=line.split(SPACE_DELIMITER);
	
				if(atmDetails.length > 0) 
				{
					
					AutomatedTellerMachine atm = new AutomatedTellerMachine(Integer.parseInt(atmDetails[0]),atmDetails[1], atmDetails[2],Integer.parseInt(atmDetails[3]));
					atmlist.add(atm);
				}
			}
			
			/*for (AutomatedTellerMachine atm1:atmlist) {
				System.out.println(atm1.getAccountNumber()+" "+atm1.getName()+" "+atm1.getBankname()+" "+atm1.getBalance());
			}*/
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				br.close();
			}
			catch(IOException ex) {
				System.out.println("Error occured while closing the BufferReader");
				ex.printStackTrace();
			}
		}
	}
	
	public void getBalanceEnquiry(int acc_no) 
	{
		this.accountNumber=acc_no;
		for (int i = 0; i < atmlist.size(); i++) 
		{
			if(atmlist.get(i).getAccountNumber()==acc_no) 
			{
				System.out.println("The balance is: "+atmlist.get(i).getBalance());
			}
			else
			{
				System.out.println("The account is not valid");
			}
		}
	}
	
	public void withdraw(int amount) 
	{
		for (int i = 0; i < atmlist.size(); i++) 
		{
			
		}
	}
}
