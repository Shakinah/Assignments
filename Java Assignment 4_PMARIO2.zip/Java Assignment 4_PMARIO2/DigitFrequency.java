package com.ford.trainings;

import java.util.Scanner;

public class DigitFrequency {

	public void checkDigitFrequency(int length)
	{
		
		int[] number=new int[10];
		int[] freq= new int[10];
		Scanner n = new Scanner(System.in);
		System.out.println("Enter the number:");
		
		for(int i=0;i<length;i++)
		{
		number[i]=n.nextInt();
		freq[i]=-1;
		}
		
		int count;
			
		for(int i = 0; i <length;i++) 
		{  
			count=1;
			  for(int j = i+1; j < length;j++)
            {
            	if(number[i]==number[j])
            	{
            		
            		count++;
            		freq[j]=0;
            	}
            }
			  
				
		if(freq[i]!=0)
		{
			freq[i]=count;
		}
	}
			
		for (int i = 0; i < number.length; i++)
		{
			
		if(freq[i]!=-1)
			{
			System.out.println("YES");
		}
		else
		{
			System.out.println("NO");
                
		}
		

}
}
}
