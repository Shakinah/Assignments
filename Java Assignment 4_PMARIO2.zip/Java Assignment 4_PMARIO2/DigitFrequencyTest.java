package com.ford.trainings;

import static org.junit.Assert.*;

import org.junit.Test;

public class DigitFrequencyTest {

	@Test
	public void TestDigitFrequency() throws Exception {
		DigitFrequency digitfreq = new DigitFrequency();
		int length=5;
		digitfreq.checkDigitFrequency(length);
	}
}
