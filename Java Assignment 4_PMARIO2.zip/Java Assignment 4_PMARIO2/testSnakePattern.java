package com.ford.trainings;

import static org.junit.Assert.*;

import org.junit.Test;

public class testSnakePattern {

	@Test
	public void testSnakePattern() throws Exception {
		
		SnakePattern obj = new SnakePattern();
		int[][] arr= {
					{1,2,3},
					{4,5,6},
					{7,8,9},
					};
		obj.printSnakePattern(arr);
	}
		
}
