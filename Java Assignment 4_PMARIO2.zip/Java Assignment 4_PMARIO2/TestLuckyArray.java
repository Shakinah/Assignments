package com.ford.trainings;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Test;

public class TestLuckyArray {

	@Test
	public void test() throws Exception {
		LuckyArray luckyarrayobj = new LuckyArray();
		 int[] arr = new int[5];
		    int length;
			System.out.println("Enter number of entries you wish to enter:");
			Scanner n = new Scanner(System.in);
			length=n.nextInt();
			System.out.println("Enter the number:");
			for(int j=0;j<length;j++)
			{
				arr[j]=n.nextInt();
			}
		      
		        for (int i = 0; i < length; i++) 
		        {
		            if(luckyarrayobj.checkLucky(arr[i])) 
		                System.out.print(arr[i] + " is Lucky \n"); 
		            else
		            System.out.print(arr[i] + " is not Lucky \n"); 
		    } 
	}
}
