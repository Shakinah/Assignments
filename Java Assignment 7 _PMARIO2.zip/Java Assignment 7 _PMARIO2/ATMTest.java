package com.ford.trainings.Shakinah;

import static org.junit.Assert.*;

import org.junit.Test;

public class ATMTest {
@Test
public void testBalanceEnquiry() throws Exception {
	
	ATMManagement atmobj = new ATMManagement();
	atmobj.readFile();
	atmobj.getBalanceEnquiry(1234567);
	
}

@Test
public void testWithdraw() throws Exception {
	ATMManagement atmobj = new ATMManagement();
	atmobj.readFile();
	atmobj.withdraw(5000,1234567);
}
}
