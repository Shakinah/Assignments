package com.ford.trainings.Shakinah;

public class AutomatedTellerMachine
{
		//long atm;
		int accountNumber;
		String name;
		String bankname;
		int balance;

	boolean isaccountvalid=true;
	
	
		
	public AutomatedTellerMachine(int accountNumber, String name, String bankname, int balance) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.bankname = bankname;
		this.balance = balance;
	
	}

	/*public long getAtm() {
			return atm;
		}

		public void setAtm(int atm) {
			this.atm = atm;
		}*/

		public AutomatedTellerMachine() {
	}

		public int getAccountNumber() {
			return accountNumber;
		}

		public void setAccountNumber(int accountNumber) {
			this.accountNumber = accountNumber;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getBankname() {
			return bankname;
		}

		public void setBankname(String bankname) {
			this.bankname = bankname;
		}
		public int getBalance() {
			return balance;
		}

		public void setBalance(int balance) {
			this.balance = balance;
		}

		public boolean isIsaccountvalid() {
			return isaccountvalid;
		}

		public void setIsaccountvalid(boolean isaccountvalid) {
			this.isaccountvalid = isaccountvalid;
		}
		@Override
		public String toString() {
			return "AutomatedTellerMachine [accountNumber=" + accountNumber + ", name=" + name + ", bankname="
					+ bankname + ", balance=" + balance + ", isaccountvalid=" + isaccountvalid + "]";
		}
		
		

}
